import AuthPage from "@/components/auth/AuthPage";
import api from "@/lib/api";
import { useEffect, useState } from "react";
import {
  LayoutDashboard,
  Wallet,
  Repeat2,
  CheckSquare,
  NotebookPen,
  Bot,
  Search,
  Bell,
  Sun,
  Moon,
  Menu,
  X,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  MoreHorizontal,
  CalendarDays,
  Clock3,
  Flame,
  CircleCheck,
  Sparkles,
  ChevronRight,
  Command,
  CircleDollarSign,
  Target,
  TrendingUp,
} from "lucide-react";
import "./App.css";

const [session, setSession] = useState(() => {
  const token = localStorage.getItem("studentlife_token");
  const storedUser = localStorage.getItem("studentlife_user");

  if (!token || !storedUser) return null;

  try {
    return { token, user: JSON.parse(storedUser) };
  } catch {
    localStorage.removeItem("studentlife_token");
    localStorage.removeItem("studentlife_user");
    return null;
  }
});

useEffect(() => {
  let cancelled = false;

  async function validateSession() {
    if (!session?.token) return;

    try {
      await api.get("/api/auth/me");
    } catch {
      if (!cancelled) {
        localStorage.removeItem("studentlife_token");
        localStorage.removeItem("studentlife_user");
        setSession(null);
      }
    }
  }

  validateSession();
  return () => { cancelled = true; };
}, []);

const handleAuthenticated = (result) => {
  setSession(result);
};
const navigation = [
  { label: "Overview", icon: LayoutDashboard, section: "Workspace" },
  { label: "Expenses", icon: Wallet, section: "Workspace" },
  { label: "Habits", icon: Repeat2, section: "Workspace" },
  { label: "Tasks", icon: CheckSquare, section: "Workspace" },
  { label: "Notes", icon: NotebookPen, section: "Workspace" },
  { label: "AI Assistant", icon: Bot, section: "Personal" },
];

const initialTasks = [
  { id: 1, title: "Review data structures notes", time: "10:30 AM", tag: "Study", done: false },
  { id: 2, title: "Complete project documentation", time: "12:00 PM", tag: "Project", done: false },
  { id: 3, title: "Track today's expenses", time: "4:00 PM", tag: "Personal", done: true },
  { id: 4, title: "Read for 20 minutes", time: "8:00 PM", tag: "Learning", done: false },
];

const habits = [
  { name: "Morning workout", detail: "Move your body", streak: 8, progress: 100 },
  { name: "Read 20 minutes", detail: "Invest in yourself", streak: 12, progress: 70 },
  { name: "Drink enough water", detail: "Stay hydrated", streak: 5, progress: 45 },
];

const spending = [
  { day: "Mon", amount: 280 },
  { day: "Tue", amount: 450 },
  { day: "Wed", amount: 190 },
  { day: "Thu", amount: 620 },
  { day: "Fri", amount: 380 },
  { day: "Sat", amount: 760 },
  { day: "Sun", amount: 320 },
];

const formatINR = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);

function Sidebar({ activePage, setActivePage, mobileOpen, setMobileOpen }) {
  return (
    <>
      {mobileOpen && (
        <button
          className="mobile-backdrop"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      )}
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <Command size={21} strokeWidth={2.4} />
          </div>
          <div>
            <div className="brand-name">dayform</div>
            <div className="brand-caption">YOUR PERSONAL SPACE</div>
          </div>
          <button
            className="icon-button mobile-close"
            onClick={() => setMobileOpen(false)}
            aria-label="Close sidebar"
          >
            <X size={18} />
          </button>
        </div>

        <button className="workspace-switch">
          <div className="workspace-avatar">P</div>
          <div className="workspace-copy">
            <strong>Personal workspace</strong>
            <span>Free plan</span>
          </div>
          <MoreHorizontal size={18} />
        </button>

        {["Workspace", "Personal"].map((section) => (
          <div className="nav-section" key={section}>
            <div className="nav-label">{section}</div>
            {navigation
              .filter((item) => item.section === section)
              .map(({ label, icon: Icon }) => (
                <button
                  key={label}
                  className={`nav-item ${activePage === label ? "nav-active" : ""}`}
                  onClick={() => {
                    setActivePage(label);
                    setMobileOpen(false);
                  }}
                >
                  <Icon size={18} strokeWidth={1.8} />
                  <span>{label}</span>
                  {label === "Tasks" && <span className="nav-count">3</span>}
                </button>
              ))}
          </div>
        ))}

        <div className="sidebar-bottom">
          <div className="focus-card">
            <div className="focus-icon"><Sparkles size={17} /></div>
            <strong>A little progress adds up.</strong>
            <p>Small steps today make a better tomorrow.</p>
            <div className="focus-progress"><span /></div>
            <div className="focus-footer"><span>Daily focus</span><span>65%</span></div>
          </div>
          <button className="profile-button">
            <div className="profile-avatar">P</div>
            <div className="profile-copy">
              <strong>Your account</strong>
              <span>Personal plan</span>
            </div>
            <MoreHorizontal size={18} />
          </button>
        </div>
      </aside>
    </>
  );
}

function MetricCard({ title, value, caption, icon: Icon, trend, tone }) {
  return (
    <article className="metric-card glass-card">
      <div className="metric-top">
        <span className="metric-title">{title}</span>
        <span className={`metric-icon ${tone}`}><Icon size={19} /></span>
      </div>
      <div className="metric-value">{value}</div>
      <div className="metric-footer">
        <span className="metric-trend"><ArrowUpRight size={14} /> {trend}</span>
        <span className="metric-caption">{caption}</span>
      </div>
    </article>
  );
}

function SpendingChart() {
  const max = Math.max(...spending.map((item) => item.amount));
  return (
    <div className="chart-wrap">
      <div className="chart-summary">
        <div>
          <div className="chart-total">{formatINR(3000)}</div>
          <div className="muted-copy">Total spending this week</div>
        </div>
        <span className="chart-pill"><TrendingUp size={14} /> This week</span>
      </div>
      <div className="bar-chart">
        {spending.map((item, index) => (
          <div className="bar-column" key={item.day}>
            <div className="bar-track">
              <div
                className={`bar-fill ${index === 5 ? "bar-highlight" : ""}`}
                style={{ height: `${(item.amount / max) * 100}%` }}
                title={`${item.day}: ${formatINR(item.amount)}`}
              />
            </div>
            <span className={`bar-label ${index === 5 ? "bar-label-active" : ""}`}>
              {item.day}
            </span>
          </div>
        ))}
      </div>
      <div className="chart-legend">
        <span><i /> Daily expenses</span>
        <span>Illustrative data</span>
      </div>
    </div>
  );
}

function Overview({ tasks, setTasks, setActivePage }) {
  const completed = tasks.filter((task) => task.done).length;

  return (
    <>
      <div className="welcome-row">
        <div>
          <div className="eyebrow"><span className="live-dot" /> YOUR PERSONAL DASHBOARD</div>
          <h1>Make room for <span>what matters.</span></h1>
          <p className="welcome-subtitle">A clearer view of your day starts here.</p>
        </div>
        <button className="primary-button" onClick={() => setActivePage("Tasks")}>
          <Plus size={17} /> New task
        </button>
      </div>

      <div className="daily-banner">
        <div className="banner-orb orb-one" />
        <div className="banner-orb orb-two" />
        <div className="banner-content">
          <div className="banner-kicker"><Sparkles size={14} /> A FRESH START</div>
          <h2>One thing at a time.</h2>
          <p>You don't have to do everything today. Just the next right thing.</p>
          <button className="banner-button" onClick={() => setActivePage("Tasks")}>
            Plan your day <ArrowUpRight size={15} />
          </button>
        </div>
        <div className="banner-stat">
          <div className="banner-stat-number">{completed}<span>/{tasks.length}</span></div>
          <div className="banner-stat-label">Tasks completed</div>
          <div className="banner-stat-track"><span style={{ width: `${(completed / tasks.length) * 100}%` }} /></div>
          <div className="banner-stat-caption">Keep your momentum going</div>
        </div>
      </div>

      <div className="section-heading">
        <div><h2>Your overview</h2><p>A little snapshot of how things are going.</p></div>
        <button className="text-button" onClick={() => setActivePage("Expenses")}>View reports <ChevronRight size={15} /></button>
      </div>

      <div className="metrics-grid">
        <MetricCard title="Monthly spending" value={formatINR(8420)} caption="vs last month" trend="12% lower" icon={Wallet} tone="purple" />
        <MetricCard title="Habits completed" value="76%" caption="of daily goals" trend="+8% this week" icon={Target} tone="green" />
        <MetricCard title="Tasks completed" value={`${completed}/${tasks.length}`} caption="today's progress" trend="Keep going" icon={CircleCheck} tone="blue" />
        <MetricCard title="Current streak" value="12 days" caption="personal best: 18" trend="On track" icon={Flame} tone="orange" />
      </div>

      <div className="dashboard-grid">
        <section className="panel glass-card spending-panel">
          <div className="panel-heading">
            <div><h3>Spending overview</h3><p>Keep an eye on where it goes.</p></div>
            <button className="icon-button" aria-label="Spending options"><MoreHorizontal size={20} /></button>
          </div>
          <SpendingChart />
        </section>

        <section className="panel glass-card tasks-panel">
          <div className="panel-heading">
            <div><h3>Today's tasks</h3><p>A few steps make a big difference.</p></div>
            <button className="icon-button" onClick={() => setActivePage("Tasks")} aria-label="View all tasks"><ArrowUpRight size={18} /></button>
          </div>
          <div className="task-list">
            {tasks.map((task) => (
              <label className={`task-row ${task.done ? "task-complete" : ""}`} key={task.id}>
                <input
                  type="checkbox"
                  checked={task.done}
                  onChange={() => setTasks((old) =>
                    old.map((item) => item.id === task.id ? { ...item, done: !item.done } : item)
                  )}
                />
                <span className="custom-check"><CircleCheck size={17} /></span>
                <span className="task-main">
                  <span className="task-title">{task.title}</span>
                  <span className="task-meta"><Clock3 size={12} /> {task.time} <span className="task-tag">{task.tag}</span></span>
                </span>
              </label>
            ))}
          </div>
          <button className="panel-bottom-link" onClick={() => setActivePage("Tasks")}>See all tasks <ChevronRight size={15} /></button>
        </section>

        <section className="panel glass-card habits-panel">
          <div className="panel-heading">
            <div><h3>Your habits</h3><p>Consistency over perfection.</p></div>
            <button className="icon-button" onClick={() => setActivePage("Habits")} aria-label="View habits"><ArrowUpRight size={18} /></button>
          </div>
          <div className="habit-list">
            {habits.map((habit) => (
              <div className="habit-row" key={habit.name}>
                <div className="habit-symbol"><CircleCheck size={17} /></div>
                <div className="habit-info">
                  <strong>{habit.name}</strong>
                  <span>{habit.detail}</span>
                  <div className="habit-track"><span style={{ width: `${habit.progress}%` }} /></div>
                </div>
                <div className="habit-streak"><Flame size={13} /> {habit.streak}d</div>
              </div>
            ))}
          </div>
          <button className="panel-bottom-link" onClick={() => setActivePage("Habits")}>Manage habits <ChevronRight size={15} /></button>
        </section>

        <section className="panel glass-card assistant-panel">
          <div className="assistant-orb"><Sparkles size={23} /></div>
          <div className="assistant-label">YOUR PERSONAL AI</div>
          <h3>A little help goes a long way.</h3>
          <p>Get ideas, reflect on your habits, or make a plan that works for you.</p>
          <button className="assistant-button" onClick={() => setActivePage("AI Assistant")}>
            Talk to your assistant <ArrowUpRight size={16} />
          </button>
        </section>
      </div>

      <div className="dashboard-footnote"><CircleDollarSign size={14} /> Dashboard currently shows illustrative data. Your saved data will appear when API integration is complete.</div>
    </>
  );
}

function PlaceholderPage({ page, setActivePage }) {
  const details = {
    Expenses: { icon: Wallet, title: "Know where it goes.", description: "Keep your spending intentional. Track expenses, understand patterns, and make your money work for you.", action: "Add an expense", cards: ["Recent transactions", "Spending by category", "Monthly summary"] },
    Habits: { icon: Repeat2, title: "Small things, done daily.", description: "Build routines that support the person you want to become.", action: "Create a habit", cards: ["Your routines", "Daily check-ins", "Streak history"] },
    Tasks: { icon: CheckSquare, title: "Clear mind. Clear priorities.", description: "Bring your tasks together and focus on what matters next.", action: "Create a task", cards: ["To do", "In progress", "Completed"] },
    Notes: { icon: NotebookPen, title: "A place for your thoughts.", description: "Keep ideas, plans, and the things you don't want to forget in one place.", action: "Write a note", cards: ["Recent notes", "Pinned", "All notes"] },
    "AI Assistant": { icon: Bot, title: "Let's think it through.", description: "Talk through your goals, plan your day, or reflect on your progress with your AI assistant.", action: "Start a conversation", cards: ["Plan my day", "Review my habits", "Understand my spending"] },
  };
  const item = details[page] || details.Expenses;
  const Icon = item.icon;

  return (
    <div className="placeholder-page">
      <div className="placeholder-icon"><Icon size={25} /></div>
      <div className="eyebrow">YOUR WORKSPACE / {page.toUpperCase()}</div>
      <h1>{item.title}</h1>
      <p className="placeholder-description">{item.description}</p>
      <div className="placeholder-cards">
        {item.cards.map((card, index) => (
          <div className="placeholder-card glass-card" key={card}>
            <div className="placeholder-card-icon"><Icon size={19} /></div>
            <span>{card}</span>
            <ArrowUpRight size={16} />
            <small>{index === 0 ? "Your workspace is ready" : "Connect your data next"}</small>
          </div>
        ))}
      </div>
      <div className="placeholder-notice"><Sparkles size={16} /> This screen is the UI foundation. Next, we'll connect it to your backend.</div>
      <button className="primary-button" onClick={() => setActivePage("Overview")}>Back to overview</button>
    </div>
  );
}

function App() {
  const [activePage, setActivePage] = useState("Overview");
  const [dark, setDark] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [tasks, setTasks] = useState(initialTasks);

  const pageTitle = activePage === "Overview" ? "Overview" : activePage;

  return (
    <div className={`app-shell ${dark ? "theme-dark" : "theme-light"}`}>
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
      />
      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-button menu-toggle" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={21} /></button>
            <div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>{pageTitle}</strong></div>
          </div>
          <div className="topbar-actions">
            <label className="search-box">
              <Search size={16} />
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search anything..." />
              <kbd>⌘ K</kbd>
            </label>
            <button className="icon-button theme-toggle" onClick={() => setDark((value) => !value)} aria-label="Toggle light and dark theme">
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button className="icon-button notification-button" aria-label="Notifications"><Bell size={18} /><span /></button>
            <div className="topbar-avatar">P</div>
          </div>
        </header>

        <div className="page-content">
          {activePage === "Overview" ? (
            <Overview tasks={tasks} setTasks={setTasks} setActivePage={setActivePage} />
          ) : (
            <PlaceholderPage page={activePage} setActivePage={setActivePage} />
          )}
          <footer className="app-footer"><span>dayform <span className="footer-dot">·</span> make time for you</span><span><CalendarDays size={13} /> Built for a more intentional day</span></footer>
        </div>
      </main>
    </div>
  );
}

export default App;
